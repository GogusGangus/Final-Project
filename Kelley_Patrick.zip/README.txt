Scriber is intended to be a simple journaling program. This is how it works:


Buttons and Windows:--------------------------------------------------------------
                    
The New Entry button will open a window where you must enter the date, title, and body of your entry before saving it. The date must be in the shown format (MM/DD/YYYY). From here you can go back to the Main Menu without creating an entry by pressing Cancel, or you can finalize the entry by pressing Save and Quit.

The View Entries button opens a window that allows you to click an entry and view, edit, or delete it. Viewing will create a small window of the entry, which can be useful as a digital sticky note. Currently, the Refresh button serves no purpose. It does work exactly as it should, but the list already stays updated. 
----------------------------------------------------------------------------------

State of Progress:----------------------------------------------------------------

All buttons should work with full functionality. Creating, editing, deleting, and viewing should work with ordinary use. The text box for the body of the entries has not been configured to automatically break lines when reaching the edge of the box, but any line break created by the user will be saved properly and kept upon viewing and editing. If anything appears to not work for any reason, check the journal_data.txt file and look for a break in format. If possible, send me your .txt file and whatever you entered so I can make improvements.
----------------------------------------------------------------------------------

