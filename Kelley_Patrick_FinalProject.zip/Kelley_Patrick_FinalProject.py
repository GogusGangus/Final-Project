# Scriber - Journaling Program
# Author: Patrick Kelley
# Description: Scriber is a simple journaling program where users can create, view, edit, and delete entries.


import sys
from breezypythongui import EasyFrame
import tkinter as tk
import re


def exit_program():  # Generic function for Exit buttons
    sys.exit()


class MainMenu(EasyFrame):  # Initial window on startup that leads to the New Entry window and View Entries window.
    def __init__(self):
        EasyFrame.__init__(self, title="Scriber", width="600", height="300", background="tan", resizable=True)
        self.welcomeLabel = self.addLabel(text="Welcome to Scriber!", sticky="NEWS", row=1, column=1, background="tan")
        self.newEntryButton = self.addButton(text="New Entry", row=2, rowspan=2, column=1, command=self.new_entry)
        self.viewEntriesButton = self.addButton(text="View Entries", row=3, rowspan=2, column=1, command=self.view_entries)
        self.exitButton = self.addButton(text="Exit", row=4, column=1, command=exit_program)
        self.imageInkpot = self.addLabel(text="Inkpot and Quill", row=3, column=0, background="tan", sticky="ES")
        self.imageInkpot2 = self.addLabel(text="Inkpot and Quill", row=3, column=2, background="tan", sticky="WS")
        self.inkpotImage = tk.PhotoImage(file="inkpot.png")
        self.inkpotImage2 = tk.PhotoImage(file="inkpot2.png")
        self.imageInkpot["image"] = self.inkpotImage
        self.imageInkpot2["image"] = self.inkpotImage2

    def new_entry(self):  # These functions move the user between the main menu and the other windows.
        self.destroy()
        NewEntryWindow(self).mainloop()

    def view_entries(self):
        self.destroy()
        ViewEntriesMenu(self).mainloop()

    def recreate_main_menu(self):
        self.destroy()
        MainMenu().mainloop()


class NewEntryWindow(EasyFrame):  # Allows user to create or edit an entry with a date, title, and body.
    def __init__(self, main_menu, edit_target=None, edit_targets=None, edit_mode=False):
        EasyFrame.__init__(self, title="Scriber", width="600", height="300", background="tan", resizable=True)
        self.main_menu = main_menu       # These allow entries to pass between windows.
        self.edit_target = edit_target
        self.edit_targets = edit_targets
        self.edit_mode = edit_mode
        self.cornerImage = self.addLabel(text="Book and Pen", row=0, column=0, rowspan=2, sticky="NWS", background="tan")
        self.bookImage = tk.PhotoImage(file="writing.png")
        self.cornerImage["image"] = self.bookImage
        self.entryDate = self.addLabel(text="Entry Date:", row=0, column=1, sticky="NEWS", background="tan")
        self.chosenDate = self.addTextField(text="MM/DD/YYYY", row=0, column=2, columnspan=1, sticky="NEWS")
        self.entryTitle = self.addLabel(text="Title:", row=1, column=1, sticky="NEWS", background="tan")
        self.chosenTitle = self.addTextField(text="", row=1, column=2, columnspan=1, sticky="NEWS")
        self.entryBox = self.addTextArea(text="", row=3, column=0, columnspan=3, width=10, height=8, wrap="word")
        self.saveButton = self.addButton(text="Save and Exit", row=5, column=2, command=self.save_and_exit)
        self.cancelButton = self.addButton(text="Cancel", row=5, column=0, command=self.back_to_main)
        if self.edit_mode:          # Edit mode is activated when the user presses the Edit Entry button in the View
            self.enter_edit_mode()  # Entries window. Edit mode fills the boxes and changes the button functions.

    def save_and_exit(self):                        # Checks for all valid data and writes entry into the .txt file.
        date_info = self.chosenDate.getText()
        date = self.validate_date_format(date_info)
        if date:
            title = self.chosenTitle.getText()
            if title != "":
                entry_text = self.entryBox.getText()
                if entry_text != "\n":
                    entry_text = entry_text.replace("\n", "-_-")  # Linebreaks are replaced so entries maintain format
                    with open("journal_data.txt", "a+") as file:  # when moved between .txt files and other windows.
                        file.write(f"{date_info} : [{title}] {entry_text}\n")
                        file.write("%$%\n")
                        file.flush()
                        self.destroy()
                        self.main_menu.recreate_main_menu()
                else:
                    self.messageBox(title="Oops", message="You can't save a blank entry.")
            else:
                self.messageBox(title="Oops", message="Please enter a title for your entry.")

    def validate_date_format(self, date_info):  # Ensures date is valid and in the format of MM/DD/YYYY
        if len(date_info) == 10 and date_info.count('/') == 2:
            acceptable = "0123456789/"
            for unit in date_info:
                if unit not in acceptable:
                    self.messageBox(title="Oops", message="Invalid Date. Only numbers and forward slashes.")
                    return False
                else:
                    return True
            else:
                self.messageBox(title="Oops", message="Invalid Date.")
        else:
            self.messageBox(title="Oops", message="Invalid date format. Please use MM/DD/YYYY.")
            return False

    def back_to_main(self):
        self.destroy()
        self.main_menu.recreate_main_menu()

    def enter_edit_mode(self):                          # Uses chosen entry to fill boxes. Also changes the function of
        self.chosenDate.setText(self.edit_targets[0])   # the buttons from Create to Edit and returns user to the View
        self.chosenTitle.setText(self.edit_targets[1])  # window instead of the Main Menu.
        self.entryBox.setText(self.edit_targets[2])
        self.saveButton["command"] = self.edit_and_exit
        self.cancelButton["command"] = self.back_to_view

    def back_to_view(self):
        self.destroy()
        ViewEntriesMenu(self).mainloop()

    def edit_and_exit(self):                         # The same as save_and_exit except it searches for the original
        date_info = self.chosenDate.getText()        # entry and writes the new version in its place.
        date = self.validate_date_format(date_info)
        counter = 0
        if date:
            title = self.chosenTitle.getText()
            if title != "":
                entry_text = self.entryBox.getText()
                if entry_text != "":
                    entry_text = entry_text.replace("\n", "-_-")
                    new_entry = f"{date_info} : [{title}] {entry_text}\n"
                    old_entry = self.edit_target
                    old_entry = old_entry.replace("\n", "-_-")
                    with open("journal_data.txt", "r") as file:
                        file_data = file.readlines()
                    with open("journal_data.txt", "w") as file:
                        for line in file_data:     # The file is rewritten line-by-line. Once the original entry is
                            if counter == 1:       # found, the new version is written in its place, and the original
                                counter += 1       # is skipped.
                                file.write("%$%\n")
                                continue
                            elif line.strip() != old_entry.strip():
                                file.write(line)
                            else:
                                counter += 1
                                file.write(new_entry)
                        file.flush()       # This updates the program during use, so entries can be viewed
                        self.destroy()     # without having to restart
                        self.main_menu.recreate_main_menu()
                else:
                    self.messageBox(title="Oops", message="You can't save a blank entry.")
            else:
                self.messageBox(title="Oops", message="Please enter a title for you entry.")


class ViewEntriesMenu(EasyFrame):   # This window allows the user to create, view, edit, and delete entries.
    def __init__(self, main_menu):  # They can also return to the Main Menu or Refresh the list.
        self.main_menu = main_menu
        self.entry_view_windows = []
        EasyFrame.__init__(self, title="Scriber", width="600", height="300", background="tan", resizable=True)
        self.navigatePanel = self.addPanel(row=0, column=0, rowspan=1, columnspan=2, background="tan")
        self.entriesPanel = self.addPanel(row=1, column=0, rowspan=2, columnspan=3)
        self.entriesList = self.entriesPanel.addListbox(row=0, column=1, rowspan=3, columnspan=3, height=10, width=40, listItemSelected=lambda index: index)
        self.modifyPanel = self.addPanel(row=2, column=4, background="tan")
        self.viewButton = self.modifyPanel.addButton(text="View", row=1, column=4, command=self.view_entry)
        self.editButton = self.modifyPanel.addButton(text="Edit", row=2, column=4, command=self.edit_entry)
        self.deleteButton = self.modifyPanel.addButton(text="Delete", row=3, column=4, command=self.delete_entry)
        self.createEntryButton = self.modifyPanel.addButton(text="Create Entry", row=4, column=4, command=self.new_entry)
        self.exitPanel = self.addPanel(row=3, column=0, rowspan=1, columnspan=3, background="tan")
        self.exitButton = self.exitPanel.addButton(text="Exit", row=0, column=2, command=exit_program)
        self.mainMenuButton = self.exitPanel.addButton(text="Main Menu", row=0, column=0, command=self.back_to_main)
        self.generate_entries()       # The existing entries are loaded into the listbox upon startup.

    def back_to_main(self):
        self.destroy()
        self.main_menu.recreate_main_menu()

    def recreate_main_menu(self):
        self.destroy()
        MainMenu().mainloop()

    def generate_entries(self):    # Entries are read from the txt file using "%$%" as a cutoff. Then they're added
        self.entriesList.clear()   # to the listbox.
        with open("journal_data.txt", "r") as file:
            entry = ""
            for line in file:
                line = line.strip()
                if re.match(r'\d{2}/\d{2}/\d{4}', line):  # A new entry is confirmed by checking for the date format.
                    if line != "%$%":                     # This allows multi-line entries to be added to the listbox.
                        entry += line.replace("-_-", "\n")
                elif "%$%" in line:
                    self.entriesList.insert(tk.END, entry)
                    entry = ""

    def view_entry(self):                        # Creates a special window just for viewing entries
        target_info = self.separate_entry()
        target_parts = target_info[1]
        title = target_parts[1]
        body = target_parts[2]
        entry_view_window = EntryViewWindow(title, body)
        entry_view_window.mainloop()
        self.entry_view_windows.append(EntryViewWindow)

    def edit_entry(self):                     # Sends an entry from the listbox to the New Entry window.
        target_info = self.separate_entry()   # The user is returned to the View window after editing.
        edit_target = target_info[0]
        edit_targets = target_info[1]
        edit_mode = True
        self.destroy()
        NewEntryWindow(self, edit_target, edit_targets, edit_mode).mainloop()

    def separate_entry(self):                 # Separates entries into date, title, and body for use in other places.
        target = self.entriesList.getSelectedItem()
        if target:
            counter = 0
            skip = False
            date = ""
            title = ""
            body = ""
            date_done = False
            title_done = False
            for word in target:
                for char in word:
                    counter += 1
                    if skip:
                        skip = False
                        continue
                    if counter > 10:
                        date_done = True
                    if not date_done:
                        date += char
                    if char == "]":
                        title_done = True
                        skip = True
                        continue
                    if date_done and not title_done and counter > 14:
                        title += char
                    if date_done and title_done:
                        body += char
            targets = [date, title, body]
            return target, targets

    def delete_entry(self):  # Similar to edit_entry where the txt file is rewritten while skipping the chosen entry.
        delete_counter = 0
        deletion_target = self.entriesList.getSelectedItem()
        deletion_target = deletion_target.replace("\n", "-_-")
        with open("journal_data.txt", "r") as file:
            entries = file.readlines()
        with open("journal_data.txt", "w") as file:
            for line in entries:
                if delete_counter == 1:
                    delete_counter += 1
                    continue
                if deletion_target.strip() != line.strip() or delete_counter > 1:
                    file.write(line)
                else:
                    delete_counter += 1
        self.generate_entries()

    def new_entry(self):
        self.destroy()
        NewEntryWindow(self).mainloop()


class EntryViewWindow(tk.Toplevel):   # Creates a window to show a chosen entry. Written differently from
    def __init__(self, title, body):  # everything else because I simply couldn't make it work any other way.
        tk.Toplevel.__init__(self)
        self.title("Entry")
        self.pin_button = tk.Button(self, text="Pin", command=self.toggle_pin)
        self.pin_button.pack()
        title_label = tk.Label(self, text=title, justify=tk.CENTER, background="tan")
        body_text = tk.Text(self, wrap="word", background="tan")
        body_text.insert(tk.END, body)
        body_text.config(state="disabled")  # Make the Text widget read-only
        title_label.pack(fill=tk.BOTH, expand=True)
        body_text.pack(fill=tk.BOTH, expand=True)
        width = max(title_label.winfo_reqwidth(), body_text.winfo_reqwidth())
        height = max(title_label.winfo_reqheight(), body_text.winfo_reqheight(), 200)
        self.geometry(f"{width}x{height}")

    def toggle_pin(self):  # Forces window to stay on the top screen layer.
        self.attributes("-topmost", not self.attributes("-topmost"))


if __name__ == "__main__":
    MainMenu().mainloop()
